"""Derive the client's logo assets from the supplied brand artwork.

Inputs (the artwork handed over by the design owner):

* the mark: the rose glyph on a transparent background;
* the light lockup: mark + "Noobietoria" wordmark on a white background.

Outputs, written into apps/noobietoria-client/assets/:

* logo-mark.png     the mark, cropped to its ink and scaled to 256px tall;
* logo-lockup.png   the dark lockup for light surfaces, cropped and
                    background-keyed to transparency, 1024px wide;
* logo-wordmark.png the wordmark half of the lockup, for headers that place the
                    mark and the wordmark separately.

The lockup is drawn on pure white, so it is keyed out by solving, per pixel,
for the coverage `a` that best explains `pixel = a * ink + (1 - a) * white` for
either of the two ink colours actually present (black text, rose mark). That
recovers clean antialiased edges instead of leaving a white plate behind.

Usage:
    python scripts/make-logo-assets.py <mark.png> <lockup.png>
"""

import sys
from pathlib import Path

from PIL import Image

# The two inks present in the artwork; the background is pure white.
BLACK = (0, 0, 0)
ROSE = (205, 122, 123)
WHITE = 255


def ink_bbox(image):
    """Bounding box of everything that is not (near) white / not transparent."""
    width, height = image.size
    pixels = image.load()
    min_x, min_y, max_x, max_y = width, height, -1, -1
    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            if a > 8 and (r < 247 or g < 247 or b < 247):
                min_x = min(min_x, x)
                max_x = max(max_x, x)
                min_y = min(min_y, y)
                max_y = max(max_y, y)
    if max_x < 0:
        raise SystemExit("no ink found in the supplied artwork")
    return (min_x, min_y, max_x + 1, max_y + 1)


def cover_for(value, ink):
    """Coverage of `ink` over white that would produce `value`."""
    if ink == WHITE:
        return None
    return (WHITE - value) / (WHITE - ink)


def column_runs(image, threshold=24):
    """Contiguous runs of columns that contain any pixel above `threshold`."""
    width, height = image.size
    pixels = image.load()
    runs = []
    start = None
    for x in range(width):
        has_ink = any(pixels[x, y][3] > threshold for y in range(height))
        if has_ink and start is None:
            start = x
        elif not has_ink and start is not None:
            runs.append((start, x))
            start = None
    if start is not None:
        runs.append((start, width))
    return runs


def key_out_white(image):
    """Turn the white plate of `image` into transparency."""
    width, height = image.size
    pixels = image.load()
    out = Image.new("RGBA", (width, height))
    out_pixels = out.load()
    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            if a == 0:
                out_pixels[x, y] = (0, 0, 0, 0)
                continue

            best = None
            for ink in (BLACK, ROSE):
                # Solve the coverage from each channel and keep the best fit.
                covers = [cover_for(c, i) for c, i in zip((r, g, b), ink)]
                if any(c is None for c in covers):
                    continue
                cover = sum(covers) / 3.0
                cover = min(1.0, max(0.0, cover))
                predicted = tuple(
                    cover * i + (1.0 - cover) * WHITE for i in ink
                )
                error = sum((p - c) ** 2 for p, c in zip(predicted, (r, g, b)))
                if best is None or error < best[0]:
                    best = (error, ink, cover)

            if best is None or best[2] <= 0.004:
                out_pixels[x, y] = (0, 0, 0, 0)
            else:
                _, ink, cover = best
                out_pixels[x, y] = (
                    int(round(ink[0])),
                    int(round(ink[1])),
                    int(round(ink[2])),
                    int(round(cover * a)),
                )
    return out


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)

    repo = Path(__file__).resolve().parent.parent
    assets = repo / "apps" / "noobietoria-client" / "assets"
    assets.mkdir(parents=True, exist_ok=True)

    # ── Mark ──────────────────────────────────────────────────────────────────
    mark = Image.open(sys.argv[1]).convert("RGBA")
    mark = mark.crop(ink_bbox(mark))
    scale = 256 / mark.height
    mark = mark.resize(
        (max(1, round(mark.width * scale)), 256), Image.LANCZOS
    )
    mark.save(assets / "logo-mark.png")
    print(f"logo-mark.png    {mark.size[0]}x{mark.size[1]}")

    # ── Light lockup, keyed off its white plate ───────────────────────────────
    lockup = Image.open(sys.argv[2]).convert("RGBA")
    lockup = lockup.crop(ink_bbox(lockup))
    keyed = key_out_white(lockup)
    scale = 1024 / keyed.width
    keyed = keyed.resize(
        (1024, max(1, round(keyed.height * scale))), Image.LANCZOS
    )
    keyed.save(assets / "logo-lockup.png")
    print(f"logo-lockup.png  {keyed.size[0]}x{keyed.size[1]}")

    # ── Wordmark only, split off the lockup at its widest gap ────────────────
    gaps = column_runs(keyed)
    if len(gaps) < 2:
        raise SystemExit("could not locate the mark/wordmark split in the lockup")
    # The first run is the mark; the rest is the wordmark, starting at the widest
    # gap that follows the mark.
    widest = max(
        range(len(gaps) - 1),
        key=lambda i: gaps[i + 1][0] - gaps[i][1],
    )
    split = max(gaps[widest][1], gaps[0][1])
    wordmark = keyed.crop((split, 0, keyed.width, keyed.height))
    wordmark = wordmark.crop(ink_bbox(wordmark))
    wordmark.save(assets / "logo-wordmark.png")
    print(f"logo-wordmark.png {wordmark.size[0]}x{wordmark.size[1]}")


if __name__ == "__main__":
    main()
